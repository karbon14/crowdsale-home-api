---
name: 🤗 Support Question
about: If you have a question 💬, please check out our StackOverflow!

---

--------------^ Click "Preview" for a nicer view!
We primarily use GitHub as an issue tracker; for usage and support questions, please check out these resources below. Thanks! 😁.

---

* StackOverflow: https://stackoverflow.com/questions/tagged/karbon14 using the tag `karbon14`
* Twitter: If it's just a quick question you can ping our Twitter: https://twitter.com/K14crypto