module.exports = {
  coverageDirectory: '.coverage',
  collectCoverage: false,
  coveragePathIgnorePatterns: ['src/index.js', 'src/routes.js', 'src/log.js'],
}
