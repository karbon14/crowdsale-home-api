const { API_URL } = process.env

export const configuration = {
  API_URL: API_URL || 'http://localhost:3000',
}
